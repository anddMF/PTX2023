import json

count = 0

with open('source.json', 'r', encoding="utf8") as file_json:
    data = json.load(file_json)

for obj in data:
    file_name = f'{count}.txt'

    with open(file_name, 'w') as file_w:
        file_w.write(obj['description'])

    count+=1